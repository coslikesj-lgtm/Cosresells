import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { DM_Sans, Permanent_Marker } from "next/font/google";
import { DoodleDefs } from "@/components/doodles";
import "./globals.css";

const marker = Permanent_Marker({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-marker",
  display: "swap",
});

const body = DM_Sans({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  title: "cos's whole sale",
};

export const viewport: Viewport = {
  themeColor: "#fff8e7",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${marker.variable} ${body.variable}`}>
      <body className="min-h-screen antialiased">
        <DoodleDefs />
        {children}
      </body>
    </html>
  );
}
