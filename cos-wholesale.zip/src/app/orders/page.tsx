import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { submissions } from "@/db/schema";
import { Header } from "@/components/Header";

export const dynamic = "force-dynamic";

export default async function OrdersPage() {
  const allSubmissions = await db
    .select()
    .from(submissions)
    .orderBy(desc(submissions.createdAt))
    .limit(100);

  return (
    <>
      <Header />
      <main className="min-h-screen px-5 py-12">
        <div className="mx-auto max-w-6xl">
          <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="font-display text-4xl sm:text-5xl">Submissions</h1>
              <p className="mt-2 text-base font-medium text-slate-700">
                All submitted orders and special requests are saved here in real-time and emailed to coslikesj@gmail.com
              </p>
            </div>
            <Link
              href="/"
              className="rounded-xl border-[3px] border-ink bg-white px-5 py-2.5 font-display text-lg shadow-[3px_3px_0_0_#111] transition hover:bg-sun"
            >
              ← Back to store
            </Link>
          </div>

          {allSubmissions.length === 0 ? (
            <div className="rounded-3xl border-[3px] border-ink bg-white/80 p-12 text-center shadow-[6px_6px_0_0_#111]">
              <p className="font-display text-2xl">No orders submitted yet.</p>
              <p className="mt-2 text-slate-600">
                When customers submit the order form or special requests, they will appear here.
              </p>
            </div>
          ) : (
            <div className="grid gap-6">
              {allSubmissions.map((sub) => (
                <div
                  key={sub.id}
                  className="rounded-3xl border-[3px] border-ink bg-white p-6 shadow-[6px_6px_0_0_#111]"
                >
                  <div className="flex flex-wrap items-start justify-between gap-4 border-b-[2px] border-slate-200 pb-4">
                    <div className="flex items-center gap-3">
                      <span
                        className={`rounded-xl border-[2px] border-ink px-3 py-1 font-display text-sm ${
                          sub.kind === "order" ? "bg-sun" : "bg-bubblegum text-white"
                        }`}
                      >
                        {sub.kind === "order" ? "Order" : "Special Request"}
                      </span>
                      <h2 className="font-display text-2xl">
                        {sub.product || sub.itemName || "Item"}
                      </h2>
                    </div>
                    <span className="text-sm font-semibold text-slate-500">
                      {new Date(sub.createdAt).toLocaleString()}
                    </span>
                  </div>

                  <div className="mt-4 grid gap-6 md:grid-cols-2">
                    <div className="flex flex-col gap-2.5 text-base">
                      <div>
                        <span className="font-bold text-slate-600">Customer Email:</span>{" "}
                        <a
                          href={`mailto:${sub.email}`}
                          className="font-bold text-ink underline"
                        >
                          {sub.email}
                        </a>
                      </div>

                      <div>
                        <span className="font-bold text-slate-600">Colorway:</span>{" "}
                        <span className="font-semibold">{sub.colorway}</span>
                      </div>

                      <div>
                        <span className="font-bold text-slate-600">Size:</span>{" "}
                        <span className="font-semibold">{sub.size}</span>
                      </div>

                      {sub.link ? (
                        <div>
                          <span className="font-bold text-slate-600">Reference Link:</span>{" "}
                          <a
                            href={sub.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="break-all font-semibold text-sky-700 underline"
                          >
                            {sub.link}
                          </a>
                        </div>
                      ) : null}
                    </div>

                    {sub.photo ? (
                      <div className="flex flex-col items-start gap-2">
                        <span className="font-bold text-slate-600">Customer Photo:</span>
                        <a
                          href={`/api/photo/${sub.id}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="group relative block overflow-hidden rounded-2xl border-[3px] border-ink bg-slate-100"
                        >
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img
                            src={`/api/photo/${sub.id}`}
                            alt="Uploaded item"
                            className="h-44 w-44 object-cover transition group-hover:scale-105"
                          />
                          <span className="absolute bottom-0 inset-x-0 bg-ink/80 py-1 text-center text-xs font-bold text-white">
                            View full photo ↗
                          </span>
                        </a>
                      </div>
                    ) : null}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
      <footer className="border-t-[3px] border-ink bg-ink px-5 py-8 text-center font-display text-2xl text-white">
        cos&apos;s whole sale
      </footer>
    </>
  );
}
