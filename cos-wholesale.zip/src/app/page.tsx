import { Contact } from "@/components/Contact";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { HowToUse } from "@/components/HowToUse";
import { OrderForm } from "@/components/OrderForm";
import { ProductGrid } from "@/components/ProductGrid";
import { SpecialRequest } from "@/components/SpecialRequest";

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <HowToUse />
        <ProductGrid />
        <OrderForm />
        <SpecialRequest />
        <Contact />
      </main>
      <footer className="border-t-[3px] border-ink bg-ink px-5 py-8 text-center font-display text-2xl text-white">
        cos&apos;s whole sale
      </footer>
    </>
  );
}
