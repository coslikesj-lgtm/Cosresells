import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { submissions } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const numId = Number(id);
  if (isNaN(numId)) {
    return new Response("Not found", { status: 404 });
  }

  const [row] = await db
    .select({
      photo: submissions.photo,
      photoType: submissions.photoType,
      photoName: submissions.photoName,
    })
    .from(submissions)
    .where(eq(submissions.id, numId))
    .limit(1);

  if (!row || !row.photo) {
    return new Response("Photo not found", { status: 404 });
  }

  return new Response(new Uint8Array(row.photo), {
    headers: {
      "Content-Type": row.photoType || "image/jpeg",
      "Content-Disposition": `inline; filename="${row.photoName || "photo.jpg"}"`,
      "Cache-Control": "public, max-age=86400",
    },
  });
}
