import type { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { submissions } from "@/db/schema";
import { productBySlug } from "@/lib/products";
import { sendEmail, type EmailAttachment } from "@/lib/mailer";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_PHOTO_BYTES = 10 * 1024 * 1024; // 10MB
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const cleanText = (value: FormDataEntryValue | null, max = 500) =>
  typeof value === "string" ? value.trim().slice(0, max) : "";

const fail = (message: string, status = 400) =>
  Response.json({ ok: false, error: message }, { status });

function normalizeReferenceLink(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return "";
  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed;
  }
  if (trimmed.includes(".") && !trimmed.includes(" ")) {
    return `https://${trimmed}`;
  }
  return trimmed;
}

export async function POST(req: NextRequest) {
  let form: FormData;
  try {
    form = await req.formData();
  } catch (err) {
    console.error("Failed to parse form data:", err);
    return fail("Invalid form submission", 400);
  }

  // Honeypot: silently ignore bots
  if (cleanText(form.get("website"))) {
    return Response.json({ ok: true, message: "Submitted" });
  }

  const kind = cleanText(form.get("kind")) || "order";
  const email = cleanText(form.get("email")).toLowerCase();
  const colorway = cleanText(form.get("colorway"));
  const size = cleanText(form.get("size"), 50);

  if (!email || !EMAIL_RE.test(email)) {
    return fail("A valid email address is required", 400);
  }
  if (!colorway) {
    return fail("Colorway is required", 400);
  }
  if (!size) {
    return fail("Size is required", 400);
  }

  const host =
    req.headers.get("x-forwarded-host") ||
    req.headers.get("host") ||
    "localhost:3000";
  const proto = req.headers.get("x-forwarded-proto") || "https";
  const origin = req.headers.get("origin") || `${proto}://${host}`;

  let subject: string;
  let fields: Array<[string, string]>;
  let attachment: EmailAttachment | undefined;
  let row: typeof submissions.$inferInsert;

  if (kind === "order") {
    const productSlug = cleanText(form.get("product"));
    const product = productBySlug(productSlug);
    const productName = product ? product.name : productSlug;
    const productPrice = product ? product.price : "";

    if (!productName) {
      return fail("Product selection is required", 400);
    }

    const photo = form.get("photo");
    if (!(photo instanceof File) || photo.size === 0) {
      return fail("A required photo is needed", 400);
    }
    if (photo.size > MAX_PHOTO_BYTES) {
      return fail("Photo is too large (max 10MB)", 400);
    }

    const content = Buffer.from(await photo.arrayBuffer());
    const contentType = photo.type || "image/jpeg";
    const filename = photo.name || "order-photo.jpg";
    attachment = { filename, contentType, content };

    subject = `Order: ${productName} ${productPrice ? `(${productPrice})` : ""}`.trim();
    fields = [
      ["Product", productName],
      ...(productPrice ? ([["Price", productPrice]] as Array<[string, string]>) : []),
      ["Colorway", colorway],
      ["Size", size],
    ];

    row = {
      kind: "order",
      product: productName,
      colorway,
      size,
      email,
      photoName: filename,
      photoType: contentType,
      photo: content,
    };
  } else if (kind === "special") {
    const rawLink = cleanText(form.get("link"), 1000);
    const link = normalizeReferenceLink(rawLink);
    const itemName = cleanText(form.get("name"));

    if (!rawLink || !link) {
      return fail("A reference link is required", 400);
    }
    if (!itemName) {
      return fail("Item name is required", 400);
    }

    const photo = form.get("photo");
    let photoContent: Buffer | null = null;
    let photoType: string | null = null;
    let photoName: string | null = null;

    if (photo instanceof File && photo.size > 0 && photo.size <= MAX_PHOTO_BYTES) {
      photoContent = Buffer.from(await photo.arrayBuffer());
      photoType = photo.type || "image/jpeg";
      photoName = photo.name || "reference-photo.jpg";
      attachment = { filename: photoName, contentType: photoType, content: photoContent };
    }

    subject = `Special request: ${itemName}`;
    fields = [
      ["Item Name", itemName],
      ["Reference Link", link],
      ["Colorway", colorway],
      ["Size", size],
    ];

    row = {
      kind: "special",
      link,
      itemName,
      colorway,
      size,
      email,
      photoName: photoName || undefined,
      photoType: photoType || undefined,
      photo: photoContent || undefined,
    };
  } else {
    return fail("Invalid submission type", 400);
  }

  // 1. Always store the submission in the PostgreSQL database so no request is lost
  let rowId: number | null = null;
  try {
    const [saved] = await db
      .insert(submissions)
      .values(row)
      .returning({ id: submissions.id });
    rowId = saved?.id ?? null;
  } catch (err) {
    console.error("Database insert error:", err);
  }

  // 2. Dispatch the email to coslikesj@gmail.com
  let sent = false;
  try {
    sent = await sendEmail({
      subject,
      replyTo: email,
      fields,
      attachment,
      origin,
    });
  } catch (err) {
    console.error("Email dispatch exception:", err);
  }

  if (sent && rowId !== null) {
    try {
      await db
        .update(submissions)
        .set({ emailed: true })
        .where(eq(submissions.id, rowId));
    } catch {
      // ignore
    }
  }

  return Response.json({
    ok: true,
    id: rowId,
    emailed: sent,
    message: "Submitted",
  });
}
