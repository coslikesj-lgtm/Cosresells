import { desc } from "drizzle-orm";
import { db } from "@/db";
import { submissions } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const list = await db
      .select({
        id: submissions.id,
        kind: submissions.kind,
        product: submissions.product,
        link: submissions.link,
        itemName: submissions.itemName,
        colorway: submissions.colorway,
        size: submissions.size,
        email: submissions.email,
        photoName: submissions.photoName,
        photoType: submissions.photoType,
        emailed: submissions.emailed,
        createdAt: submissions.createdAt,
      })
      .from(submissions)
      .orderBy(desc(submissions.createdAt))
      .limit(100);

    return Response.json({ ok: true, submissions: list });
  } catch (err) {
    console.error("Failed to query submissions:", err);
    return Response.json({ ok: false, error: "Database error" }, { status: 500 });
  }
}
