import { readFileSync, existsSync } from "node:fs";
import { join } from "node:path";

export const dynamic = "force-dynamic";

export async function GET() {
  const zipPath = join(process.cwd(), "public", "cos-wholesale.zip");

  if (!existsSync(zipPath)) {
    return new Response("Zip file not generated", { status: 404 });
  }

  const fileBuffer = readFileSync(zipPath);

  return new Response(fileBuffer, {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": 'attachment; filename="cos-wholesale.zip"',
      "Cache-Control": "no-store",
    },
  });
}
