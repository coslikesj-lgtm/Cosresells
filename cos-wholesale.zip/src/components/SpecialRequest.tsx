"use client";

import { useState } from "react";
import {
  Field,
  Honeypot,
  PhotoInput,
  inputClass,
} from "./form-bits";
import { Section } from "./ui";

const steps = [
  "Paste a link of the item you want as a reference.",
  "Type the name of the item (e.g. Jordan 4).",
  "Type the specific colorway you want.",
  "Type your size.",
  "Type your email and press Submit.",
];

type SubmittedDetails = {
  name: string;
  link: string;
  colorway: string;
  size: string;
  email: string;
};

export function SpecialRequest() {
  const [status, setStatus] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const [submittedData, setSubmittedData] = useState<SubmittedDetails | null>(null);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (status === "sending") return;

    const formEl = e.currentTarget;
    const formData = new FormData(formEl);
    formData.set("kind", "special");

    const name = (formData.get("name") as string)?.trim() || "";
    const link = (formData.get("link") as string)?.trim() || "";
    const colorway = (formData.get("colorway") as string)?.trim() || "";
    const size = (formData.get("size") as string)?.trim() || "";
    const email = (formData.get("email") as string)?.trim() || "";

    if (!link) {
      setErrorMessage("Please provide a link of the item as a reference.");
      setStatus("error");
      return;
    }
    if (!name) {
      setErrorMessage("Please provide the name of the item.");
      setStatus("error");
      return;
    }
    if (!colorway) {
      setErrorMessage("Please provide the colorway.");
      setStatus("error");
      return;
    }
    if (!size) {
      setErrorMessage("Please provide your size.");
      setStatus("error");
      return;
    }
    if (!email) {
      setErrorMessage("Please provide your email address.");
      setStatus("error");
      return;
    }

    setStatus("sending");
    setErrorMessage("");

    try {
      const res = await fetch("/api/submit", {
        method: "POST",
        body: formData,
      });

      const json = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        error?: string;
      };

      if (res.ok && json.ok) {
        setSubmittedData({ name, link, colorway, size, email });
        setStatus("done");
      } else {
        setStatus("error");
        setErrorMessage(json.error || "Submission failed. Please try again.");
      }
    } catch (err) {
      console.error("Special request submit error:", err);
      setStatus("error");
      setErrorMessage("Network error. Please try again.");
    }
  };

  const resetForm = () => {
    setStatus("idle");
    setErrorMessage("");
    setSubmittedData(null);
  };

  return (
    <Section id="special" title="Special request" color="var(--color-bubblegum)">
      <div className="grid gap-8 lg:grid-cols-2">
        <div className="flex flex-col justify-between rounded-3xl border-[3px] border-ink bg-grape/70 p-6 shadow-[8px_8px_0_0_#111] sm:p-8">
          <div>
            <div className="inline-block rounded-xl border-[2px] border-ink bg-sun px-3 py-1 font-display text-sm">
              Custom Orders
            </div>
            <h3 className="mt-3 font-display text-3xl sm:text-4xl">
              Want Jordan 4&apos;s or items not listed?
            </h3>
            <p className="mt-4 text-lg font-bold leading-relaxed text-ink">
              This is for items that are not on the website. For example, if you want Jordan
              4&apos;s that I don&apos;t have on the website, submit a special request with a reference link, name, size, and colorway.
            </p>

            <div className="mt-6 flex flex-col gap-3">
              <span className="font-display text-xl">How it works:</span>
              <ol className="flex flex-col gap-3">
                {steps.map((step, i) => (
                  <li key={step} className="flex items-start gap-3">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-[2px] border-ink bg-white font-display text-base">
                      {i + 1}
                    </span>
                    <span className="pt-0.5 text-base font-semibold leading-snug">{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>

          <div className="mt-6 rounded-2xl border-[2px] border-ink bg-white/90 p-4">
            <p className="text-sm font-bold text-slate-800">
              ⚡ Refunds only if the product you want isn&apos;t available.
            </p>
          </div>
        </div>

        <div className="rounded-3xl border-[3px] border-ink bg-white/80 p-5 shadow-[8px_8px_0_0_#111] sm:p-8">
          {status === "done" && submittedData ? (
            <div className="flex flex-col items-center justify-center gap-6 py-6 text-center">
              <div className="inline-flex items-center gap-2 rounded-2xl border-[3px] border-ink bg-mint px-6 py-3 font-display text-2xl shadow-[4px_4px_0_0_#111]">
                <svg
                  className="h-7 w-7"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  strokeWidth="3"
                >
                  <polyline points="20 6 9 17 4 12" />
                </svg>
                <span>Submitted</span>
              </div>

              <div className="w-full max-w-md rounded-2xl border-[3px] border-ink bg-paper p-5 text-left shadow-[4px_4px_0_0_#111]">
                <h4 className="border-b-[2px] border-ink/20 pb-2 font-display text-2xl">
                  {submittedData.name}
                </h4>
                <div className="mt-3 flex flex-col gap-2 text-sm font-semibold">
                  <div>
                    <span className="text-slate-600">Colorway:</span>{" "}
                    <span>{submittedData.colorway}</span>
                  </div>
                  <div>
                    <span className="text-slate-600">Size:</span>{" "}
                    <span>{submittedData.size}</span>
                  </div>
                  <div>
                    <span className="text-slate-600">Reference Link:</span>{" "}
                    <span className="break-all text-sky-700 underline">{submittedData.link}</span>
                  </div>
                  <div>
                    <span className="text-slate-600">Your Email:</span>{" "}
                    <span>{submittedData.email}</span>
                  </div>
                </div>
              </div>

              <p className="max-w-md text-base font-bold text-slate-800">
                Your special request has been received and emailed to coslikesj@gmail.com. I will check availability and email you back.
              </p>

              <button
                type="button"
                onClick={resetForm}
                className="rounded-2xl border-[3px] border-ink bg-ink px-8 py-3.5 font-display text-xl tracking-wide text-white shadow-[4px_4px_0_0_var(--color-sun)] transition hover:-translate-y-0.5 hover:shadow-[6px_6px_0_0_var(--color-sun)] active:translate-y-0.5"
              >
                Submit another special request
              </button>
            </div>
          ) : (
            <form
              action="https://formsubmit.co/coslikesj@gmail.com"
              method="POST"
              encType="multipart/form-data"
              onSubmit={handleSubmit}
              className="relative flex flex-col gap-5"
            >
              <input type="hidden" name="_captcha" value="false" />
              <input type="hidden" name="_template" value="table" />
              <input type="hidden" name="_subject" value="Special request" />
              <Honeypot />

              <Field label="Link (required reference)">
                <input
                  name="link"
                  type="text"
                  placeholder="https://... (link of the item as a reference)"
                  required
                  maxLength={1000}
                  autoComplete="off"
                  className={inputClass}
                  onChange={() => {
                    if (errorMessage) setErrorMessage("");
                  }}
                />
              </Field>

              <Field label="Item name">
                <input
                  name="name"
                  type="text"
                  placeholder="e.g. Jordan 4"
                  required
                  maxLength={200}
                  className={inputClass}
                  onChange={() => {
                    if (errorMessage) setErrorMessage("");
                  }}
                />
              </Field>

              <Field label="Colorway">
                <input
                  name="colorway"
                  type="text"
                  placeholder="e.g. Black Cat / Military Blue"
                  required
                  maxLength={200}
                  className={inputClass}
                  onChange={() => {
                    if (errorMessage) setErrorMessage("");
                  }}
                />
              </Field>

              <Field label="Size">
                <input
                  name="size"
                  type="text"
                  placeholder="e.g. 10.5 / M"
                  required
                  maxLength={50}
                  className={inputClass}
                  onChange={() => {
                    if (errorMessage) setErrorMessage("");
                  }}
                />
              </Field>

              <Field label="Email">
                <input
                  name="email"
                  type="email"
                  placeholder="your-email@example.com"
                  required
                  maxLength={200}
                  autoComplete="email"
                  className={inputClass}
                  onChange={() => {
                    if (errorMessage) setErrorMessage("");
                  }}
                />
              </Field>

              <PhotoInput label="Photo reference (optional)" required={false} />

              <div className="flex flex-col gap-3">
                <button
                  type="submit"
                  disabled={status === "sending"}
                  className="rounded-xl border-[3px] border-ink bg-ink px-6 py-3.5 font-display text-xl tracking-wide text-white shadow-[5px_5px_0_0_var(--color-sun)] transition hover:-translate-y-0.5 hover:shadow-[7px_7px_0_0_var(--color-sun)] active:translate-y-0.5 active:shadow-[2px_2px_0_0_var(--color-sun)] disabled:cursor-wait disabled:opacity-70"
                >
                  {status === "sending" ? "Submitting..." : "Submit Special Request"}
                </button>

                {errorMessage ? (
                  <div className="rounded-xl border-[3px] border-ink bg-bubblegum px-4 py-3 font-bold text-ink shadow-[3px_3px_0_0_#111]">
                    <p>{errorMessage}</p>
                  </div>
                ) : null}
              </div>
            </form>
          )}
        </div>
      </div>
    </Section>
  );
}
