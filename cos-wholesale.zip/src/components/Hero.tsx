import type { CSSProperties } from "react";
import Link from "next/link";
import { Doodle, type DoodleSpec } from "./doodles";

const bubbles: Array<{
  spec: DoodleSpec;
  price: string;
  bg: string;
  tilt: string;
  delay: string;
  hideOnSmall?: boolean;
}> = [
  {
    spec: { kind: "runners", fill: "#ffa552" },
    price: "$125",
    bg: "#ffe9a8",
    tilt: "-6deg",
    delay: "0s",
  },
  {
    spec: { kind: "hoodie", fill: "#7be0a0" },
    price: "$60",
    bg: "#ffd1dc",
    tilt: "4deg",
    delay: "0.6s",
  },
  {
    spec: { kind: "airpods", fill: "#ffffff", stem: "mid", tip: true, anc: true },
    price: "$35",
    bg: "#cfeaff",
    tilt: "-3deg",
    delay: "1.2s",
  },
  {
    spec: { kind: "pants", fill: "#ff8fb1" },
    price: "$55",
    bg: "#e2d6ff",
    tilt: "6deg",
    delay: "1.8s",
    hideOnSmall: true,
  },
  {
    spec: { kind: "tee", fill: "#ffd93d" },
    price: "$35",
    bg: "#cdf5da",
    tilt: "-5deg",
    delay: "2.4s",
    hideOnSmall: true,
  },
];

export function Hero() {
  return (
    <section id="top" className="px-5 pb-6 pt-12 sm:pt-20">
      <div className="mx-auto flex max-w-6xl flex-col items-center text-center">
        <h1 className="font-display text-6xl leading-[0.95] sm:text-8xl lg:text-9xl">
          <span className="-rotate-2 inline-block">cos&apos;s</span>{" "}
          <span
            className="rotate-1 inline-block px-3"
            style={{
              backgroundImage:
                "linear-gradient(transparent 58%, var(--color-sun) 58%)",
            }}
          >
            whole sale
          </span>
        </h1>
        <svg
          viewBox="0 0 300 20"
          className="mt-3 h-5 w-64 sm:w-96"
          fill="none"
          stroke="#111"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
          filter="url(#doodle-wobble)"
        >
          <path d="M6 12 q12 -12 24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0" />
        </svg>

        <div className="mt-12 flex items-center justify-center">
          {bubbles.map((b, i) => (
            <div
              key={i}
              className={`floaty -ml-3 first:ml-0 sm:-ml-5 ${
                b.hideOnSmall ? "hidden md:block" : ""
              }`}
              style={
                {
                  "--tilt": b.tilt,
                  animationDelay: b.delay,
                  zIndex: i % 2 === 0 ? 2 : 1,
                } as CSSProperties
              }
            >
              <div
                className="relative h-28 w-28 rounded-full border-[3px] border-ink p-3 shadow-[5px_5px_0_0_#111] sm:h-36 sm:w-36 lg:h-44 lg:w-44 lg:p-4"
                style={{ backgroundColor: b.bg }}
              >
                <Doodle spec={b.spec} price={b.price} />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-wrap items-center justify-center gap-4">
          <Link
            href="#products"
            className="rounded-xl border-[3px] border-ink bg-ink px-7 py-3.5 font-display text-xl tracking-wide text-white shadow-[5px_5px_0_0_var(--color-sun)] transition hover:-translate-y-0.5 hover:shadow-[7px_7px_0_0_var(--color-sun)] active:translate-y-0.5 active:shadow-[2px_2px_0_0_var(--color-sun)]"
          >
            Products
          </Link>
          <Link
            href="#order"
            className="rounded-xl border-[3px] border-ink bg-sun px-7 py-3.5 font-display text-xl tracking-wide text-ink shadow-[5px_5px_0_0_#111] transition hover:-translate-y-0.5 hover:shadow-[7px_7px_0_0_#111] active:translate-y-0.5 active:shadow-[2px_2px_0_0_var(--color-sun)]"
          >
            Order form
          </Link>
          <Link
            href="#how"
            className="rounded-xl border-[3px] border-ink bg-white px-7 py-3.5 font-display text-xl tracking-wide shadow-[5px_5px_0_0_#111] transition hover:-translate-y-0.5 hover:bg-sun hover:shadow-[7px_7px_0_0_#111] active:translate-y-0.5 active:shadow-[2px_2px_0_0_#111]"
          >
            How to use
          </Link>
        </div>
      </div>
    </section>
  );
}
