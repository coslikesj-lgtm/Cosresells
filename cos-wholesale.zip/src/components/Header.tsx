import Link from "next/link";

const links = [
  { href: "/#how", label: "How to use" },
  { href: "/#products", label: "Products" },
  { href: "/#order", label: "Order form" },
  { href: "/#special", label: "Special request" },
  { href: "/#contact", label: "Contact" },
  { href: "/orders", label: "Orders" },
];

export function Header() {
  return (
    <header className="sticky top-0 z-30 border-b-[3px] border-ink bg-paper/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-3 md:flex-row md:items-center md:justify-between">
        <Link href="/" className="font-display text-2xl leading-none sm:text-3xl">
          cos&apos;s whole sale
        </Link>
        <div className="flex flex-wrap items-center gap-2">
          <nav
            aria-label="Main"
            className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1 md:pb-0"
          >
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="shrink-0 rounded-full border-[3px] border-transparent px-3 py-1 text-sm font-bold transition hover:border-ink hover:bg-sun"
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <a
            href="/api/download"
            download="cos-wholesale.zip"
            className="shrink-0 rounded-full border-[2px] border-ink bg-sun px-3 py-1 text-xs font-extrabold uppercase tracking-wider text-ink shadow-[2px_2px_0_0_#111] transition hover:bg-ink hover:text-white"
          >
            📦 Download ZIP
          </a>
        </div>
      </div>
    </header>
  );
}
