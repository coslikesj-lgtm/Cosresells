"use client";

import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { CameraIcon } from "./icons";

export const inputClass =
  "w-full rounded-xl border-[3px] border-ink bg-white px-4 py-3 text-base font-medium outline-none transition focus:-translate-y-0.5 focus:shadow-[4px_4px_0_0_#111] focus:ring-0";

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="font-display text-lg tracking-wide">{label}</span>
      {children}
    </label>
  );
}

/** Honeypot field: hidden from people, bots fill it in. */
export function Honeypot() {
  return (
    <input
      type="text"
      name="website"
      tabIndex={-1}
      autoComplete="off"
      aria-hidden="true"
      className="absolute -left-[9999px] h-0 w-0 opacity-0 pointer-events-none"
    />
  );
}

export function PhotoInput({
  label = "Photo (required)",
  required = true,
}: {
  label?: string;
  required?: boolean;
}) {
  const [preview, setPreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState("");
  const [broken, setBroken] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  const handleFile = (file?: File) => {
    if (!file) return;
    setBroken(false);
    setFileName(file.name);
    setPreview(URL.createObjectURL(file));
  };

  return (
    <div className="flex flex-col gap-1.5">
      <span className="font-display text-lg tracking-wide">{label}</span>
      <div
        className={`relative flex aspect-square w-full items-center justify-center overflow-hidden rounded-2xl border-[3px] border-dashed border-ink bg-white transition hover:bg-sun/30 focus-within:shadow-[4px_4px_0_0_#111] ${
          isDragging ? "bg-sun/50 border-solid" : ""
        }`}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          const file = e.dataTransfer.files?.[0];
          handleFile(file);
        }}
      >
        <input
          type="file"
          name="photo"
          accept="image/*"
          required={required}
          aria-label={label}
          className="absolute inset-0 z-10 h-full w-full cursor-pointer opacity-0"
          onChange={(e) => {
            const file = e.target.files?.[0];
            handleFile(file);
          }}
        />
        {preview && !broken ? (
          <div className="relative h-full w-full">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={preview}
              alt="Selected photo"
              onError={() => setBroken(true)}
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-x-0 bottom-0 bg-ink/80 p-2 text-center text-xs font-bold text-white backdrop-blur-sm">
              <p className="truncate">{fileName}</p>
              <span className="text-[10px] uppercase tracking-wider text-sun">
                Click to change photo
              </span>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3 p-4 text-center">
            <CameraIcon className="h-14 w-14" />
            <div className="flex flex-col gap-1">
              <span className="font-display text-lg">Add photo</span>
              <span className="text-xs font-medium text-slate-700">
                Click or drag & drop photo here {required ? "" : "(optional)"}
              </span>
            </div>
            {fileName ? (
              <span className="max-w-full truncate text-sm font-bold text-ink">
                {fileName}
              </span>
            ) : null}
          </div>
        )}
      </div>
    </div>
  );
}

export type SubmitStatus = "idle" | "sending" | "done" | "error";

export function useSubmit(kind: "order" | "special") {
  const [status, setStatus] = useState<SubmitStatus>("idle");
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [formKey, setFormKey] = useState(0);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (status === "sending") return;

    const formEl = e.currentTarget;
    const data = new FormData(formEl);
    data.set("kind", kind);

    setStatus("sending");
    setErrorMessage("");

    try {
      const res = await fetch("/api/submit", {
        method: "POST",
        body: data,
      });

      const json = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        error?: string;
      };

      if (res.ok && json.ok) {
        setStatus("done");
        setFormKey((k) => k + 1);
      } else {
        setStatus("error");
        setErrorMessage(json.error || "Submission failed. Please try again.");
      }
    } catch (err) {
      console.error("Form submit error:", err);
      setStatus("error");
      setErrorMessage("Network error. Please try again.");
    }
  }

  function onChange() {
    if (status === "done" || status === "error") {
      setStatus("idle");
      setErrorMessage("");
    }
  }

  return { status, errorMessage, formKey, onSubmit, onChange };
}

export function SubmitRow({
  status,
  errorMessage,
}: {
  status: SubmitStatus;
  errorMessage?: string;
}) {
  return (
    <div className="flex flex-col gap-3">
      <button
        type="submit"
        disabled={status === "sending"}
        className="rounded-xl border-[3px] border-ink bg-ink px-6 py-3.5 font-display text-xl tracking-wide text-white shadow-[5px_5px_0_0_var(--color-sun)] transition hover:-translate-y-0.5 hover:shadow-[7px_7px_0_0_var(--color-sun)] active:translate-y-0.5 active:shadow-[2px_2px_0_0_var(--color-sun)] disabled:cursor-wait disabled:opacity-70"
      >
        {status === "sending" ? "Submitting..." : "Submit"}
      </button>

      <div aria-live="polite" className="min-h-7">
        {status === "done" ? (
          <div className="inline-flex items-center gap-2 rounded-xl border-[3px] border-ink bg-mint px-4 py-2 font-display text-lg text-ink shadow-[3px_3px_0_0_#111]">
            <svg
              className="h-5 w-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              strokeWidth="3"
            >
              <polyline points="20 6 9 17 4 12" />
            </svg>
            <span>Submitted</span>
          </div>
        ) : null}

        {status === "error" ? (
          <div className="inline-block rounded-xl border-[3px] border-ink bg-bubblegum px-4 py-2 font-bold text-ink shadow-[3px_3px_0_0_#111]">
            <p>{errorMessage || "Something went wrong. Try again."}</p>
          </div>
        ) : null}
      </div>
    </div>
  );
}
