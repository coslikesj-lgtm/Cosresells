import type { ReactNode } from "react";

export function Section({
  id,
  title,
  color = "var(--color-sun)",
  children,
}: {
  id: string;
  title: string;
  color?: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-28 px-5 py-14 sm:py-16">
      <div className="mx-auto max-w-6xl">
        <h2 className="mb-8 font-display text-4xl leading-tight sm:text-5xl">
          <span
            className="-rotate-1 inline-block px-2"
            style={{
              backgroundImage: `linear-gradient(transparent 55%, ${color} 55%)`,
            }}
          >
            {title}
          </span>
        </h2>
        {children}
      </div>
    </section>
  );
}
