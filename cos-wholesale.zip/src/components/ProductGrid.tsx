"use client";

import { Doodle, Scribbles } from "./doodles";
import { Section } from "./ui";
import { products } from "@/lib/products";

const CARD_COLORS = [
  "#ffe9a8",
  "#ffd1dc",
  "#cfeaff",
  "#cdf5da",
  "#ffd9b3",
  "#e2d6ff",
];

export const SELECT_PRODUCT_EVENT = "select-product";

export function selectAndScrollToOrder(slug: string) {
  window.dispatchEvent(new CustomEvent(SELECT_PRODUCT_EVENT, { detail: slug }));
  const orderSection = document.getElementById("order");
  if (orderSection) {
    orderSection.scrollIntoView({ behavior: "smooth" });
  }
}

export function ProductGrid() {
  return (
    <Section id="products" title="Products" color="var(--color-mint)">
      <ul className="grid grid-cols-1 gap-6 min-[480px]:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {products.map((product, i) => (
          <li
            key={product.slug}
            className="group relative flex flex-col justify-between rounded-3xl border-[3px] border-ink p-4 shadow-[6px_6px_0_0_#111] transition duration-200 hover:-translate-y-1 hover:shadow-[9px_9px_0_0_#111]"
            style={{ backgroundColor: CARD_COLORS[i % CARD_COLORS.length] }}
          >
            <div>
              {/* Top Doodle Container with Price on doodle */}
              <div
                onClick={() => selectAndScrollToOrder(product.slug)}
                className="relative aspect-square w-full cursor-pointer p-2 transition duration-300 group-hover:-rotate-2 group-hover:scale-[1.03]"
              >
                <Scribbles index={i} />
                <Doodle spec={product.doodle} label={product.name} price={product.price} />
              </div>

              {/* Product Info with Name & Price */}
              <div className="mt-3 flex items-start justify-between gap-2">
                <h3 className="text-xl font-extrabold leading-tight text-ink">
                  {product.name}
                </h3>
                <span className="shrink-0 rounded-xl border-[2px] border-ink bg-white px-2.5 py-1 font-display text-lg tracking-wide text-ink shadow-[2px_2px_0_0_#111]">
                  {product.price}
                </span>
              </div>
            </div>

            {/* Order Action Button */}
            <div className="mt-4">
              <button
                type="button"
                onClick={() => selectAndScrollToOrder(product.slug)}
                className="flex w-full items-center justify-between rounded-xl border-[3px] border-ink bg-ink px-4 py-3 text-left font-display text-lg tracking-wide text-white shadow-[3px_3px_0_0_var(--color-sun)] transition hover:bg-white hover:text-ink active:translate-y-0.5"
              >
                <span>Order form</span>
                <span className="rounded-lg bg-sun px-2 py-0.5 text-base text-ink">
                  {product.price}
                </span>
              </button>
            </div>
          </li>
        ))}
      </ul>
    </Section>
  );
}
