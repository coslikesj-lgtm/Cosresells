import type { ReactNode } from "react";

export type DoodleKind =
  | "tee"
  | "longsleeve"
  | "hoodie"
  | "shorts"
  | "pants"
  | "socks"
  | "runners"
  | "slides"
  | "airpods";

export type EarbudStem = "long" | "mid" | "short";

export type DoodleSpec = {
  kind: DoodleKind;
  fill: string;
  /** second color (socks) */
  alt?: string;
  /** airpods only */
  stem?: EarbudStem;
  tip?: boolean;
  anc?: boolean;
};

const INK = "#111111";
const SHADE = "rgba(17,17,17,0.14)";

function Tee({ fill }: { fill: string }) {
  return (
    <>
      <path
        d="M70 30 L40 44 L16 86 L44 102 L58 82 L58 170 L142 170 L142 82 L156 102 L184 86 L160 44 L130 30 Q100 56 70 30 Z"
        fill={fill}
      />
      <path d="M77 34 Q100 60 123 34" />
      <path d="M21 77 L49 93" strokeWidth="3" />
      <path d="M179 77 L151 93" strokeWidth="3" />
      <path d="M58 158 L142 158" strokeWidth="3" />
    </>
  );
}

function LongSleeve({ fill }: { fill: string }) {
  return (
    <>
      <path
        d="M72 28 L46 40 L14 138 L40 150 L60 94 L60 172 L140 172 L140 94 L160 150 L186 138 L154 40 L128 28 Q100 54 72 28 Z"
        fill={fill}
      />
      <path d="M78 32 Q100 58 122 32" />
      <path d="M19 122 L45.7 134" strokeWidth="3" />
      <path d="M181 122 L154.3 134" strokeWidth="3" />
      <path d="M60 160 L140 160" strokeWidth="3" />
    </>
  );
}

function Hoodie({ fill }: { fill: string }) {
  return (
    <>
      <path
        d="M72 40 L44 52 L14 140 L40 152 L60 98 L60 172 L140 172 L140 98 L160 152 L186 140 L156 52 L128 40 Z"
        fill={fill}
      />
      <path d="M68 44 Q58 6 100 8 Q142 6 132 44 Q100 70 68 44 Z" fill={fill} />
      <path d="M78 38 Q100 62 122 38 Q118 20 100 20 Q82 20 78 38 Z" fill={SHADE} strokeWidth="3" />
      <path d="M90 58 L88 86" strokeWidth="3" />
      <path d="M110 58 L112 86" strokeWidth="3" />
      <circle cx="88" cy="90" r="3.5" fill={INK} />
      <circle cx="112" cy="90" r="3.5" fill={INK} />
      <path d="M68 122 L132 122 L138 156 L62 156 Z" />
      <path d="M60 161 L140 161" strokeWidth="3" />
      <path d="M19 124 L45.6 136" strokeWidth="3" />
      <path d="M181 124 L154.4 136" strokeWidth="3" />
    </>
  );
}

function Shorts({ fill }: { fill: string }) {
  return (
    <>
      <path
        d="M46 40 L154 40 L172 148 L108 154 L100 98 L92 154 L28 148 Z"
        fill={fill}
      />
      <path d="M42.7 60 L157.3 60" />
      <path d="M92 60 Q90 74 86 84" strokeWidth="3" />
      <path d="M108 60 Q110 74 114 84" strokeWidth="3" />
      <circle cx="86" cy="87" r="3.5" fill={INK} />
      <circle cx="114" cy="87" r="3.5" fill={INK} />
      <path d="M30.3 134 L94 140" strokeWidth="3" />
      <path d="M169.7 134 L106 140" strokeWidth="3" />
    </>
  );
}

function Pants({ fill }: { fill: string }) {
  return (
    <>
      <path
        d="M52 18 L148 18 L160 182 L108 182 L100 78 L92 182 L40 182 Z"
        fill={fill}
      />
      <path d="M50.7 36 L149.3 36" />
      <path d="M92 36 Q90 52 86 62" strokeWidth="3" />
      <path d="M108 36 Q110 52 114 62" strokeWidth="3" />
      <circle cx="86" cy="65" r="3.5" fill={INK} />
      <circle cx="114" cy="65" r="3.5" fill={INK} />
      <path d="M56 44 Q60 72 84 80" strokeWidth="3" />
      <path d="M144 44 Q140 72 116 80" strokeWidth="3" />
      <path d="M41.2 166 L93.2 166" strokeWidth="3" />
      <path d="M158.8 166 L106.8 166" strokeWidth="3" />
    </>
  );
}

const SOCK =
  "M0 0 L38 0 L38 62 Q38 70 46 72 L78 80 Q96 86 96 102 Q96 118 80 118 L20 118 Q0 118 0 98 Z";

function Socks({ fill, alt }: { fill: string; alt: string }) {
  return (
    <>
      <g transform="translate(88 30) rotate(10 48 59)">
        <path d={SOCK} fill={alt} />
        <path d="M0 14 L38 14" strokeWidth="3" />
        <path d="M0 26 L38 26" strokeWidth="3" />
        <path d="M76 81 Q70 98 74 117" strokeWidth="3" />
      </g>
      <g transform="translate(20 46) rotate(-6 48 59)">
        <path d={SOCK} fill={fill} />
        <path d="M0 14 L38 14" strokeWidth="3" />
        <path d="M0 26 L38 26" strokeWidth="3" />
        <path d="M0 86 Q16 90 18 118" strokeWidth="3" />
        <path d="M76 81 Q70 98 74 117" strokeWidth="3" />
      </g>
    </>
  );
}

function Runners({ fill }: { fill: string }) {
  return (
    <>
      <path d="M58 56 Q62 34 80 36 Q90 54 92 80 Z" fill={fill} />
      <path
        d="M24 136 L24 68 Q24 56 38 56 L62 54 Q70 70 84 78 L108 86 Q136 92 162 100 Q188 106 188 126 L188 136 Z"
        fill={fill}
      />
      <path d="M93 73 L99 90" strokeWidth="3" />
      <path d="M107 78 L113 94" strokeWidth="3" />
      <path d="M121 82 L127 97" strokeWidth="3" />
      <path d="M135 86 L141 101" strokeWidth="3" />
      <path d="M28 114 Q72 104 108 124 L150 128" strokeWidth="3" />
      <path
        d="M18 136 L194 136 L194 152 Q194 164 180 164 L32 164 Q18 164 18 152 Z"
        fill="#ffffff"
      />
      <path d="M30 150 L182 150" strokeWidth="3" strokeDasharray="2 9" />
    </>
  );
}

function Slides({ fill }: { fill: string }) {
  return (
    <>
      <path
        d="M18 132 L18 146 Q18 160 44 162 L160 164 Q190 164 190 146 L190 132 Z"
        fill="#ffffff"
      />
      <path
        d="M18 132 Q18 116 48 116 L158 118 Q190 120 190 132 Q190 144 160 144 L48 146 Q18 148 18 132 Z"
        fill="#f4f4f4"
      />
      <path
        d="M48 134 Q50 70 106 66 Q156 66 160 138 L134 140 Q132 96 106 92 Q78 92 72 136 Z"
        fill={fill}
      />
      <path d="M62 112 Q68 86 100 78" strokeWidth="3" strokeDasharray="2 8" />
    </>
  );
}

function Earbud({
  stem,
  tip,
  fill,
}: {
  stem: EarbudStem;
  tip: boolean;
  fill: string;
}) {
  const len = { long: 50, mid: 38, short: 26 }[stem];
  return (
    <>
      <path
        d={`M-6 10 L-6 ${len} Q-6 ${len + 7} 0 ${len + 7} Q6 ${len + 7} 6 ${len} L6 10 Z`}
        fill={fill}
      />
      {tip ? <ellipse cx="-20" cy="3" rx="8" ry="10" fill={SHADE} /> : null}
      <ellipse cx="0" cy="0" rx="19" ry="17" fill={fill} />
      <path d="M-9 -6 Q-2 -12 7 -8" strokeWidth="3" />
    </>
  );
}

function Airpods({
  fill,
  stem,
  tip,
  anc,
}: {
  fill: string;
  stem: EarbudStem;
  tip: boolean;
  anc: boolean;
}) {
  const len = { long: 50, mid: 38, short: 26 }[stem];
  const y = 98 - len;
  return (
    <>
      <g transform={`translate(70 ${y}) rotate(10)`}>
        <Earbud stem={stem} tip={tip} fill={fill} />
      </g>
      <g transform={`translate(130 ${y}) scale(-1 1) rotate(10)`}>
        <Earbud stem={stem} tip={tip} fill={fill} />
      </g>
      <rect x="50" y="108" width="100" height="68" rx="26" fill={fill} />
      <path d="M50 136 L150 136" />
      <circle cx="100" cy="154" r="4" fill={INK} />
      {anc ? (
        <>
          <path d="M34 30 Q24 44 34 58" strokeWidth="3" />
          <path d="M20 22 Q6 44 20 66" strokeWidth="3" />
          <path d="M166 30 Q176 44 166 58" strokeWidth="3" />
          <path d="M180 22 Q194 44 180 66" strokeWidth="3" />
        </>
      ) : null}
    </>
  );
}

function renderShape(spec: DoodleSpec): ReactNode {
  switch (spec.kind) {
    case "tee":
      return <Tee fill={spec.fill} />;
    case "longsleeve":
      return <LongSleeve fill={spec.fill} />;
    case "hoodie":
      return <Hoodie fill={spec.fill} />;
    case "shorts":
      return <Shorts fill={spec.fill} />;
    case "pants":
      return <Pants fill={spec.fill} />;
    case "socks":
      return <Socks fill={spec.fill} alt={spec.alt ?? "#ffffff"} />;
    case "runners":
      return <Runners fill={spec.fill} />;
    case "slides":
      return <Slides fill={spec.fill} />;
    case "airpods":
      return (
        <Airpods
          fill={spec.fill}
          stem={spec.stem ?? "mid"}
          tip={spec.tip ?? false}
          anc={spec.anc ?? false}
        />
      );
  }
}

/** Hand-drawn price tag doodle directly on the SVG illustration */
function DoodlePriceTag({ price }: { price: string }) {
  const isLarge = price.length >= 4; // e.g. "$125"
  const tagW = isLarge ? 58 : 48;
  const tagH = 26;
  const tagX = 200 - tagW - 10;
  const tagY = 12;

  return (
    <g transform={`rotate(-4 ${tagX + tagW / 2} ${tagY + tagH / 2})`}>
      {/* Tag shadow */}
      <rect
        x={tagX + 2.5}
        y={tagY + 2.5}
        width={tagW}
        height={tagH}
        rx="8"
        fill={INK}
        opacity="0.25"
      />
      {/* Tag body */}
      <rect
        x={tagX}
        y={tagY}
        width={tagW}
        height={tagH}
        rx="8"
        fill="#ffd93d"
        stroke={INK}
        strokeWidth="3"
      />
      {/* Little tag punch hole */}
      <circle cx={tagX + 6} cy={tagY + tagH / 2} r="2" fill={INK} />
      {/* Price text in marker style */}
      <text
        x={tagX + (tagW + 5) / 2}
        y={tagY + tagH / 2 + 5}
        textAnchor="middle"
        fill={INK}
        stroke="none"
        fontSize={isLarge ? "14" : "15"}
        fontWeight="900"
        fontFamily="var(--font-marker), 'Permanent Marker', Impact, sans-serif"
      >
        {price}
      </text>
    </g>
  );
}

/** Hand-drawn style product doodle with optional price tag. */
export function Doodle({
  spec,
  label,
  price,
  className = "h-full w-full",
}: {
  spec: DoodleSpec;
  label?: string;
  price?: string;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 200 200"
      className={className}
      role={label ? "img" : undefined}
      aria-label={label ? `${label} - ${price || ""}` : undefined}
      aria-hidden={label ? undefined : true}
    >
      <ellipse cx="100" cy="188" rx="64" ry="5" fill={INK} opacity="0.12" />
      <g
        fill="none"
        stroke={INK}
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
        filter="url(#doodle-wobble)"
      >
        {renderShape(spec)}
      </g>
      {price ? <DoodlePriceTag price={price} /> : null}
    </svg>
  );
}

/** Shared SVG filter that gives every doodle its wobbly, hand-drawn edge. */
export function DoodleDefs() {
  return (
    <svg
      width="0"
      height="0"
      className="pointer-events-none absolute"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <filter id="doodle-wobble" x="-8%" y="-8%" width="116%" height="116%">
          <feTurbulence
            type="fractalNoise"
            baseFrequency="0.025"
            numOctaves="2"
            seed="4"
            result="noise"
          />
          <feDisplacementMap
            in="SourceGraphic"
            in2="noise"
            scale="4"
            xChannelSelector="R"
            yChannelSelector="G"
          />
        </filter>
      </defs>
    </svg>
  );
}

const STAR = "M0 -14 Q2 -2 14 0 Q2 2 0 14 Q-2 2 -14 0 Q-2 -2 0 -14 Z";

/** Little background scribbles behind a product doodle. */
export function Scribbles({ index }: { index: number }) {
  const v = index % 4;
  return (
    <svg
      viewBox="0 0 200 200"
      className="pointer-events-none absolute inset-0 h-full w-full"
      aria-hidden="true"
      fill="none"
      stroke={INK}
      strokeWidth="3"
      strokeLinecap="round"
      strokeLinejoin="round"
      filter="url(#doodle-wobble)"
    >
      {v === 0 ? (
        <>
          <path d={STAR} transform="translate(26 28)" fill="#fff" />
          <path d="M150 170 q8 -10 16 0 t16 0" />
          <circle cx="176" cy="30" r="5" />
        </>
      ) : null}
      {v === 1 ? (
        <>
          <path d="M24 28 h14 M31 21 v14" />
          <path d="M168 164 h14 M175 157 v14" />
          <circle cx="170" cy="32" r="4" fill="#fff" />
          <circle cx="30" cy="170" r="4" fill="#fff" />
        </>
      ) : null}
      {v === 2 ? (
        <>
          <path d="M20 34 q6 -16 18 -8 q8 8 -4 14 q-12 2 -10 -10" />
          <path d={STAR} transform="translate(172 168) scale(0.9)" fill="#fff" />
          <path d="M160 26 l10 10 m0 -10 l-10 10" />
        </>
      ) : null}
      {v === 3 ? (
        <>
          <path d="M18 168 l8 -10 l8 10 l8 -10 l8 10" />
          <circle cx="172" cy="34" r="9" />
          <path d={STAR} transform="translate(30 30) scale(0.8)" fill="#fff" />
        </>
      ) : null}
    </svg>
  );
}
