"use client";

import { useEffect, useState } from "react";
import { Doodle } from "./doodles";
import {
  Field,
  Honeypot,
  PhotoInput,
  inputClass,
  useSubmit,
} from "./form-bits";
import { SELECT_PRODUCT_EVENT } from "./ProductGrid";
import { Section } from "./ui";
import { productBySlug, products, sizeOptions } from "@/lib/products";

export function OrderForm() {
  const [slug, setSlug] = useState(products[0]?.slug || "");
  const [submittedProduct, setSubmittedProduct] = useState<(typeof products)[0] | null>(null);
  const { status, errorMessage, formKey, onSubmit, onChange } = useSubmit("order");
  const selected = productBySlug(slug) || products[0];

  useEffect(() => {
    const handler = (e: Event) => {
      const next = (e as CustomEvent<string>).detail;
      if (typeof next === "string" && next) {
        setSlug(next);
        setSubmittedProduct(null);
      }
    };
    window.addEventListener(SELECT_PRODUCT_EVENT, handler);
    return () => window.removeEventListener(SELECT_PRODUCT_EVENT, handler);
  }, []);

  const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    const currentProduct = selected;
    await onSubmit(e);
    setSubmittedProduct(currentProduct);
  };

  return (
    <Section id="order" title="Order form" color="var(--color-sky)">
      <div className="rounded-3xl border-[3px] border-ink bg-white/80 p-5 shadow-[8px_8px_0_0_#111] sm:p-8">
        {status === "done" && submittedProduct ? (
          <div className="flex flex-col items-center justify-center gap-6 py-6 text-center">
            <div className="inline-flex items-center gap-2 rounded-2xl border-[3px] border-ink bg-mint px-6 py-3 font-display text-2xl shadow-[4px_4px_0_0_#111]">
              <svg
                className="h-7 w-7"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                strokeWidth="3"
              >
                <polyline points="20 6 9 17 4 12" />
              </svg>
              <span>Submitted</span>
            </div>

            <div className="flex flex-col items-center gap-2 max-w-md">
              <div className="relative h-32 w-32 rounded-2xl border-[3px] border-ink bg-sun/40 p-2">
                <Doodle spec={submittedProduct.doodle} price={submittedProduct.price} />
              </div>
              <p className="font-display text-3xl">{submittedProduct.name}</p>
              <span className="rounded-xl border-[2px] border-ink bg-white px-4 py-1 font-display text-2xl shadow-[2px_2px_0_0_#111]">
                {submittedProduct.price}
              </span>
            </div>

            <div className="flex flex-col items-center gap-4 w-full max-w-md">
              <a
                href={submittedProduct.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full rounded-2xl border-[3px] border-ink bg-ink px-8 py-4 font-display text-2xl tracking-wide text-white shadow-[6px_6px_0_0_var(--color-sun)] transition hover:-translate-y-1 hover:shadow-[8px_8px_0_0_var(--color-sun)] active:translate-y-0.5"
              >
                Pay {submittedProduct.price} with Stripe →
              </a>

              <button
                type="button"
                onClick={() => {
                  setSubmittedProduct(null);
                  onChange();
                }}
                className="rounded-xl border-[2px] border-ink bg-white px-5 py-2 font-display text-base transition hover:bg-slate-100"
              >
                Submit another order
              </button>
            </div>
          </div>
        ) : (
          <form
            key={formKey}
            action="https://formsubmit.co/coslikesj@gmail.com"
            method="POST"
            encType="multipart/form-data"
            onSubmit={handleFormSubmit}
            onChange={onChange}
            className="relative grid gap-8 md:grid-cols-2"
          >
            {/* FormSubmit standard fields */}
            <input type="hidden" name="_captcha" value="false" />
            <input type="hidden" name="_template" value="table" />
            <input
              type="hidden"
              name="_subject"
              value={`Order: ${selected?.name || "Product"} (${selected?.price || ""})`}
            />
            <Honeypot />

            <PhotoInput label="Photo (required)" />

            <div className="flex flex-col gap-5">
              <Field label="Product">
                <div className="flex items-center gap-3">
                  <select
                    name="product"
                    required
                    value={slug}
                    onChange={(e) => setSlug(e.target.value)}
                    className={`${inputClass} appearance-none bg-[length:1.1rem] bg-[right_1rem_center] bg-no-repeat pr-11`}
                    style={{
                      backgroundImage:
                        "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23111' stroke-width='3.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")",
                    }}
                  >
                    {products.map((p) => (
                      <option key={p.slug} value={p.slug}>
                        {p.name} — {p.price}
                      </option>
                    ))}
                  </select>
                  <div className="relative h-16 w-16 shrink-0 rounded-xl border-[3px] border-ink bg-sun/40 p-1">
                    {selected ? (
                      <Doodle spec={selected.doodle} price={selected.price} />
                    ) : null}
                  </div>
                </div>
              </Field>

              <Field label="Colorway">
                <input
                  name="colorway"
                  type="text"
                  placeholder="e.g. Pink / Black / White"
                  required
                  maxLength={200}
                  className={inputClass}
                />
              </Field>

              <Field label="Size">
                <input
                  name="size"
                  type="text"
                  placeholder="e.g. M / L / 10.5"
                  required
                  maxLength={50}
                  list="order-sizes"
                  autoComplete="off"
                  className={inputClass}
                />
                <datalist id="order-sizes">
                  {(selected ? sizeOptions[selected.category] : []).map((s) => (
                    <option key={s} value={s} />
                  ))}
                </datalist>
              </Field>

              <Field label="Email">
                <input
                  name="email"
                  type="email"
                  placeholder="your-email@example.com"
                  required
                  maxLength={200}
                  autoComplete="email"
                  className={inputClass}
                />
              </Field>

              <div className="flex flex-col gap-3">
                <button
                  type="submit"
                  disabled={status === "sending"}
                  className="flex items-center justify-center gap-2 rounded-xl border-[3px] border-ink bg-ink px-6 py-3.5 font-display text-xl tracking-wide text-white shadow-[5px_5px_0_0_var(--color-sun)] transition hover:-translate-y-0.5 hover:shadow-[7px_7px_0_0_var(--color-sun)] active:translate-y-0.5 active:shadow-[2px_2px_0_0_var(--color-sun)] disabled:cursor-wait disabled:opacity-70"
                >
                  <span>{status === "sending" ? "Submitting..." : "Submit Order"}</span>
                  {selected ? (
                    <span className="rounded-md bg-sun px-2 py-0.5 text-base text-ink font-bold">
                      {selected.price}
                    </span>
                  ) : null}
                </button>

                {errorMessage ? (
                  <div className="rounded-xl border-[3px] border-ink bg-bubblegum px-4 py-2 font-bold text-ink">
                    <p>{errorMessage}</p>
                  </div>
                ) : null}
              </div>
            </div>
          </form>
        )}
      </div>
    </Section>
  );
}
