import { Section } from "./ui";

const steps: Array<{ text: string; bg: string; link?: { href: string; label: string } }> = [
  {
    text: "Select the product you want to order from the website.",
    bg: "#ffe9a8",
    link: { href: "#products", label: "View products" },
  },
  {
    text: "Fill out the order form with the required photo, the name of the specific colorway you want, the size you want, and your email.",
    bg: "#cfeaff",
    link: { href: "#order", label: "Go to order form" },
  },
  {
    text: "Press Submit, then purchase through the Stripe payment link for your item.",
    bg: "#cdf5da",
  },
  {
    text: "If you want an item not on the website (for example Jordan 4's), submit a special request with a link of the item as a reference, the name, size, and colorway.",
    bg: "#e2d6ff",
    link: { href: "#special", label: "Special request" },
  },
];

export function HowToUse() {
  return (
    <Section id="how" title="How to use" color="var(--color-bubblegum)">
      <ol className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {steps.map((step, i) => (
          <li
            key={step.text}
            className="relative flex flex-col gap-4 rounded-3xl border-[3px] border-ink p-6 pt-8 shadow-[6px_6px_0_0_#111]"
            style={{ backgroundColor: step.bg }}
          >
            <span className="absolute -top-5 left-5 flex h-11 w-11 items-center justify-center rounded-full border-[3px] border-ink bg-white font-display text-xl shadow-[3px_3px_0_0_#111]">
              {i + 1}
            </span>
            <p className="text-lg font-semibold leading-snug">{step.text}</p>
            {step.link ? (
              <a
                href={step.link.href}
                className="mt-auto self-start rounded-xl border-[3px] border-ink bg-white px-4 py-2 font-display text-lg tracking-wide transition hover:bg-sun active:translate-y-0.5"
              >
                {step.link.label}
              </a>
            ) : null}
          </li>
        ))}

        <li className="flex items-center rounded-3xl border-[3px] border-ink bg-sun p-6 shadow-[6px_6px_0_0_#111] sm:col-span-2 lg:col-span-2">
          <p className="font-display text-2xl leading-snug">
            Refunds only if the product you want isn&apos;t available.
          </p>
        </li>
      </ol>
    </Section>
  );
}
