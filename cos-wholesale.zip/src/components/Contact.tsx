import { InstagramIcon, MailIcon, PhoneIcon, TikTokIcon } from "./icons";
import { Section } from "./ui";

const contacts = [
  {
    label: "Instagram",
    value: "@coswholesale",
    href: "https://www.instagram.com/coswholesale",
    Icon: InstagramIcon,
    bg: "#ffd1dc",
    external: true,
  },
  {
    label: "TikTok",
    value: "@coswholesale",
    href: "https://www.tiktok.com/@coswholesale",
    Icon: TikTokIcon,
    bg: "#cfeaff",
    external: true,
  },
  {
    label: "Phone",
    value: "914-689-1796",
    href: "tel:+19146891796",
    Icon: PhoneIcon,
    bg: "#cdf5da",
    external: false,
  },
  {
    label: "Email",
    value: "coslikesj@gmail.com",
    href: "mailto:coslikesj@gmail.com",
    Icon: MailIcon,
    bg: "#ffe9a8",
    external: false,
  },
];

export function Contact() {
  return (
    <Section id="contact" title="Contact" color="var(--color-tangerine)">
      <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {contacts.map(({ label, value, href, Icon, bg, external }) => (
          <li key={label}>
            <a
              href={href}
              {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
              className="flex h-full flex-col gap-4 rounded-3xl border-[3px] border-ink p-6 shadow-[6px_6px_0_0_#111] transition duration-200 hover:-translate-y-1 hover:shadow-[9px_9px_0_0_#111] active:translate-y-0"
              style={{ backgroundColor: bg }}
            >
              <span className="flex h-14 w-14 items-center justify-center rounded-full border-[3px] border-ink bg-white">
                <Icon className="h-7 w-7" />
              </span>
              <span className="font-display text-2xl">{label}</span>
              <span className="break-all text-lg font-bold">{value}</span>
            </a>
          </li>
        ))}
      </ul>
    </Section>
  );
}
