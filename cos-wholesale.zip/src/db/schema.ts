import {
  boolean,
  customType,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

const bytea = customType<{ data: Buffer; driverData: Buffer }>({
  dataType() {
    return "bytea";
  },
});

// Every order form / special request is logged here, then emailed.
export const submissions = pgTable("submissions", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull(),
  product: text("product"),
  link: text("link"),
  itemName: text("item_name"),
  colorway: text("colorway").notNull(),
  size: text("size").notNull(),
  email: text("email").notNull(),
  photoName: text("photo_name"),
  photoType: text("photo_type"),
  photo: bytea("photo"),
  emailed: boolean("emailed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
