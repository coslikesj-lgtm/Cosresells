import nodemailer from "nodemailer";

/** Where every order form and special request is delivered. */
export function ownerEmail() {
  return process.env.ORDER_EMAIL_TO || "coslikesj@gmail.com";
}

export type EmailAttachment = {
  filename: string;
  contentType: string;
  content: Buffer;
};

export type OutgoingEmail = {
  subject: string;
  /** the customer's email, used as Reply-To */
  replyTo: string;
  fields: Array<[label: string, value: string]>;
  attachment?: EmailAttachment;
  origin?: string;
};

const escapeHtml = (s: string) =>
  s.replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c,
  );

/** Option 1: SMTP (e.g. a Gmail app password). Used when SMTP_PASS or GMAIL_APP_PASSWORD is set. */
async function sendViaSmtp(msg: OutgoingEmail): Promise<boolean> {
  const pass = process.env.SMTP_PASS || process.env.GMAIL_APP_PASSWORD;
  if (!pass) return false;

  const user = process.env.SMTP_USER || ownerEmail();
  const port = Number(process.env.SMTP_PORT || 465);
  const host = process.env.SMTP_HOST || "smtp.gmail.com";

  const transport = nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass },
  });

  const rows: Array<[string, string]> = [...msg.fields, ["Email", msg.replyTo]];
  const textContent = rows.map(([k, v]) => `${k}: ${v}`).join("\n");
  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 2px solid #111; border-radius: 12px; background: #fff8e7;">
      <h2 style="font-size: 24px; margin-bottom: 16px; color: #111;">cos's whole sale - ${escapeHtml(msg.subject)}</h2>
      <table cellpadding="8" style="width: 100%; border-collapse: collapse; background: #fff; border-radius: 8px; overflow: hidden;">
        ${rows
          .map(
            ([k, v]) =>
              `<tr><td style="border: 1px solid #ddd; padding: 10px; font-weight: bold; width: 35%; color: #333;">${escapeHtml(
                k,
              )}</td><td style="border: 1px solid #ddd; padding: 10px; color: #111;">${escapeHtml(
                v,
              )}</td></tr>`,
          )
          .join("")}
      </table>
    </div>
  `;

  const attachments = msg.attachment
    ? [
        {
          filename: msg.attachment.filename,
          content: msg.attachment.content,
          contentType: msg.attachment.contentType,
        },
      ]
    : [];

  await transport.sendMail({
    from: `"cos's whole sale" <${user}>`,
    to: ownerEmail(),
    replyTo: msg.replyTo,
    subject: msg.subject,
    text: textContent,
    html: htmlContent,
    attachments,
  });

  return true;
}

/** Option 2: Resend API if RESEND_API_KEY is configured */
async function sendViaResend(msg: OutgoingEmail): Promise<boolean> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) return false;

  const rows: Array<[string, string]> = [...msg.fields, ["Email", msg.replyTo]];
  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 2px solid #111; border-radius: 12px; background: #fff8e7;">
      <h2 style="font-size: 24px; margin-bottom: 16px; color: #111;">cos's whole sale - ${escapeHtml(msg.subject)}</h2>
      <table cellpadding="8" style="width: 100%; border-collapse: collapse; background: #fff;">
        ${rows
          .map(
            ([k, v]) =>
              `<tr><td style="border: 1px solid #ddd; padding: 10px; font-weight: bold; width: 35%;">${escapeHtml(
                k,
              )}</td><td style="border: 1px solid #ddd; padding: 10px;">${escapeHtml(
                v,
              )}</td></tr>`,
          )
          .join("")}
      </table>
    </div>
  `;

  const body: Record<string, unknown> = {
    from: process.env.RESEND_FROM || "cos's whole sale <onboarding@resend.dev>",
    to: [ownerEmail()],
    reply_to: msg.replyTo,
    subject: msg.subject,
    html: htmlContent,
  };

  if (msg.attachment) {
    body.attachments = [
      {
        filename: msg.attachment.filename,
        content: msg.attachment.content.toString("base64"),
      },
    ];
  }

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  return res.ok;
}

const LINKY = /:\/\/|www\.|[a-z0-9]\.[a-z]{2,}/i;

function linksPage(links: Array<[string, string]>) {
  const items = links
    .map(([label, value]) => {
      const href = /^https?:\/\//i.test(value) ? value : `https://${value}`;
      const anchor = /\s/.test(value)
        ? escapeHtml(value)
        : `<a href="${escapeHtml(href)}">${escapeHtml(value)}</a>`;
      return `<p><b>${escapeHtml(label)}</b><br>${anchor}</p>`;
    })
    .join("");
  return `<!doctype html><meta charset="utf-8"><body style="font-family:sans-serif;font-size:18px;padding:24px">${items}</body>`;
}

/** Option 3: FormSubmit.co to coslikesj@gmail.com */
async function sendViaFormSubmit(msg: OutgoingEmail): Promise<boolean> {
  const origin = "https://coswholesale.com";

  const links = msg.fields.filter(([, value]) => LINKY.test(value));

  let subject = msg.subject;
  for (const [, value] of links) {
    if (!subject.includes(value)) subject += ` - ${value}`;
  }

  const body = new FormData();
  body.append("_captcha", "false");
  body.append("_template", "table");
  body.append("_subject", subject);
  for (const [label, value] of msg.fields) {
    body.append(label, LINKY.test(value) ? "see attached" : value);
  }
  body.append("email", msg.replyTo);

  if (msg.attachment) {
    body.append(
      "attachment",
      new Blob([new Uint8Array(msg.attachment.content)], {
        type: msg.attachment.contentType,
      }),
      msg.attachment.filename,
    );
  }

  if (links.length > 0) {
    body.append(
      "attachment_links",
      new Blob([linksPage(links)], { type: "text/html" }),
      "link.html",
    );
  }

  const targetEmail = ownerEmail();
  const res = await fetch(`https://formsubmit.co/${targetEmail}`, {
    method: "POST",
    body,
    redirect: "manual",
    headers: {
      Origin: origin,
      Referer: `${origin}/`,
    },
    signal: AbortSignal.timeout(30_000),
  });

  // Any response in the 200-399 range indicates FormSubmit processed the submission
  if (res.status >= 200 && res.status < 400) {
    return true;
  }

  const errorText = await res.text().catch(() => "");
  console.error("FormSubmit HTTP status:", res.status, errorText.slice(0, 200));
  return false;
}

export async function sendEmail(msg: OutgoingEmail): Promise<boolean> {
  try {
    if (process.env.SMTP_PASS || process.env.GMAIL_APP_PASSWORD) {
      const smtpOk = await sendViaSmtp(msg);
      if (smtpOk) return true;
    }

    if (process.env.RESEND_API_KEY) {
      const resendOk = await sendViaResend(msg);
      if (resendOk) return true;
    }

    return await sendViaFormSubmit(msg);
  } catch (err) {
    console.error("Email send exception:", err);
    return false;
  }
}
