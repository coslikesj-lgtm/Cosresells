import type { DoodleSpec } from "@/components/doodles";

export type Category = "clothing" | "shoes" | "socks" | "earbuds";

export type Product = {
  slug: string;
  name: string;
  price: string;
  priceAmount: number;
  url: string;
  category: Category;
  doodle: DoodleSpec;
};

const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/'/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

function make(
  name: string,
  price: string,
  priceAmount: number,
  url: string,
  category: Category,
  doodle: DoodleSpec,
): Product {
  return { slug: slugify(name), name, price, priceAmount, url, category, doodle };
}

const WHITE = "#ffffff";
const SILVER = "#d6d6d6";
const CHARCOAL = "#4a4a4a";
const DENIM = "#6ea8e8";
const KHAKI = "#d9c2a3";

export const products: Product[] = [
  // Bape
  make("Bape hoodies", "$60", 60, "https://buy.stripe.com/dRmaEWdHL6TEdwH3Mw5gc0w", "clothing", { kind: "hoodie", fill: "#7be0a0" }),
  make("Bape tees", "$35", 35, "https://buy.stripe.com/9B6bJ047b6TE78j4QA5gc0v", "clothing", { kind: "tee", fill: "#ffd93d" }),
  make("Bape shorts", "$40", 40, "https://buy.stripe.com/28E4gybzD6TEdwH6YI5gc0E", "clothing", { kind: "shorts", fill: "#6ec1ff" }),

  // Chrome hearts
  make("Chrome hearts long sleeve", "$45", 45, "https://buy.stripe.com/9B6cN4fPTcdY50bdn65gc0K", "clothing", { kind: "longsleeve", fill: SILVER }),
  make("Chrome heart tee", "$40", 40, "https://buy.stripe.com/7sYeVccDHcdY50b82M5gc0G", "clothing", { kind: "tee", fill: CHARCOAL }),
  make("Chrome hoodies", "$60", 60, "https://buy.stripe.com/eVqcN4fPT0vg0JVfve5gc0y", "clothing", { kind: "hoodie", fill: SILVER }),
  make("Chrome socks", "$17", 17, "https://buy.stripe.com/7sYcN4cDH0vgakv3Mw5gc0B", "socks", { kind: "socks", fill: SILVER, alt: WHITE }),

  // Denim tears
  make("Denim tears hoodie", "$60", 60, "https://buy.stripe.com/3cI6oGbzD5PAakvcj25gc0x", "clothing", { kind: "hoodie", fill: DENIM }),
  make("Denim tears tee", "$35", 35, "https://buy.stripe.com/00wbJ0gTX0vg2S3fve5gc0I", "clothing", { kind: "tee", fill: DENIM }),
  make("Denim tears shorts", "$45", 45, "https://buy.stripe.com/5kQ00i7jn5PAdwH6YI5gc0D", "clothing", { kind: "shorts", fill: DENIM }),

  // Essentials
  make("Essentials hoodie", "$60", 60, "https://buy.stripe.com/28E3cuavz5PAakv0Ak5gc0C", "clothing", { kind: "hoodie", fill: KHAKI }),
  make("Essentials tee", "$35", 35, "https://buy.stripe.com/14A7sK8nrfqacsD4QA5gc0z", "clothing", { kind: "tee", fill: KHAKI }),
  make("Essentials shorts", "$45", 45, "https://buy.stripe.com/9B614mgTXfqa0JVdn65gc0A", "clothing", { kind: "shorts", fill: KHAKI }),
  make("Essentials pants", "$55", 55, "https://buy.stripe.com/9B600i6fj5PA9grera5gc0H", "clothing", { kind: "pants", fill: KHAKI }),

  // Sp5der
  make("Sp5der pants", "$55", 55, "https://buy.stripe.com/dRm4gyavzem6dwH82M5gc0M", "clothing", { kind: "pants", fill: "#ff8fb1" }),
  make("Sp5der shorts", "$45", 45, "https://buy.stripe.com/bJe4gy3374LwfEPfve5gc0N", "clothing", { kind: "shorts", fill: "#b79cff" }),

  // Supreme + Maison Margiela
  make("Supreme socks", "$17", 17, "https://buy.stripe.com/28E6oG1Z36TE3W7gzi5gc0F", "socks", { kind: "socks", fill: "#ff5a5a", alt: WHITE }),
  make("Maison Margiela tee", "$35", 35, "https://buy.stripe.com/8x2cN4eLP3Hs1NZ2Is5gc0J", "clothing", { kind: "tee", fill: WHITE }),

  // Balenciaga
  make("Balenciaga runners", "$125", 125, "https://buy.stripe.com/5kQbJ0eLP1zk78j1Eo5gc0U", "shoes", { kind: "runners", fill: "#ffa552" }),
  make("Balenci slides", "$45", 45, "https://buy.stripe.com/00w8wO5bf91Mboz3Mw5gc0L", "shoes", { kind: "slides", fill: CHARCOAL }),

  // Airpods
  make("Airpod 2's", "$20", 20, "https://buy.stripe.com/8x228q5bf4LwgIT96Q5gc0O", "earbuds", { kind: "airpods", fill: WHITE, stem: "long" }),
  make("Airpod 3's", "$25", 25, "https://buy.stripe.com/4gM6oG9rv4LwgITaaU5gc0S", "earbuds", { kind: "airpods", fill: WHITE, stem: "mid" }),
  make("Airpod 4's", "$25", 25, "https://buy.stripe.com/cNi6oGavz2Do1NZ6YI5gc0P", "earbuds", { kind: "airpods", fill: WHITE, stem: "short" }),
  make("Airpods 4's TOP ANC", "$27", 27, "https://buy.stripe.com/7sYaEWfPTa5Q9gr6YI5gc0Q", "earbuds", { kind: "airpods", fill: WHITE, stem: "short", anc: true }),
  make("Airpod pro 2 ANC TOP", "$35", 35, "https://buy.stripe.com/00w9ASeLP5PAcsD1Eo5gc0R", "earbuds", { kind: "airpods", fill: WHITE, stem: "mid", tip: true, anc: true }),
  make("Airpod pro 3 ANC TOP QUALITY", "$35", 35, "https://buy.stripe.com/4gMfZg8nr6TEdwHbeY5gc0T", "earbuds", { kind: "airpods", fill: WHITE, stem: "mid", tip: true, anc: true }),
];

export function productBySlug(slug: string): Product | undefined {
  return products.find((p) => p.slug === slug);
}

const shoeSizes = Array.from({ length: 15 }, (_, i) => String(6 + i * 0.5).replace(/\.0$/, ""));

export const sizeOptions: Record<Category, string[]> = {
  clothing: ["XS", "S", "M", "L", "XL", "XXL"],
  shoes: shoeSizes,
  socks: ["S/M", "L/XL"],
  earbuds: ["One size"],
};
